# New Blank Mautic Theme

## Description

A simple and sophisticated format template, maintaining simplicity, but with all control and responsiveness.

## Install

All you have to do is download the [zip file](https://github.com/moskoweb/New-Blank-Mautic-Theme/raw/master/New-Blank-Mautic-Theme.zip), access ```Settings > Themes```, and upload the theme.

---

# Novo Tema em Branco Mautic

## Descrição

Um template de formato simples e sofisticado, mantendo a simplicidade, mas com todo o controle e responsividade.

## Instalação

Basta apenas que você faça o download do [arquivo zip](https://github.com/moskoweb/New-Blank-Mautic-Theme/raw/master/New-Blank-Mautic-Theme.zip), acessar ```Configurações > Temas```, e fazer o upload do tema.